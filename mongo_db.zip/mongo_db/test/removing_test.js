
const assert = require('assert');
const Data = require('../models/data');

describe('Deleting Records',  ()=> {

  var data;
  // Creating the user , since Collection within the database gets empty before the test runs.
      beforeEach(function (done) {
          data = new Data({
              name: 'Rajat'
          });
          data.save().then(()=> {
              assert(data.isNew === false);
              done();
          });
      });

    it('Delete a record from MongoDB', (done)=> {
        Data.findOneAndRemove({name: 'Rajat'}).then(()=> {
          Data.findOne({name: 'Rajat'}).then((result)=> {
                assert(result === null);
                done();
            });
        });
    });

});
