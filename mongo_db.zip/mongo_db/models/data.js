
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Creating a Schema
const DataSchema = new Schema({
	name : String
});
// Creating the Model
const Data = mongoose.model('data',DataSchema);

module.exports = Data;       // To use Model outside this file
