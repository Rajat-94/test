
const assert = require('assert');
const Data = require('../models/data');

describe('Updating Records',  ()=> {

  var data;
  // Creating the user , since Collection within the database gets empty before the test runs.
      beforeEach(function (done) {
          data = new Data({
              name: 'Rajat'
          });
          data.save().then(()=> {
              assert(data.isNew === false);
              done();
          });
      });
                     // Mongoose methods have been used here to update the data within collections.
    it('Update a record from MongoDB', (done)=> {
        Data.findOneAndUpdate({name: 'Rajat'},{name : 'Vishal'}).then(()=> {
          Data.findOne({name: 'Rajat'}).then((result)=> {
                assert(result === null);
                done();
            });
        });
    });

});
