
const mongoose = require('mongoose');
mongoose.Promise = global.Promise;

before((done)=>{           // Connection should be made before anything else Run
  mongoose.connect('mongodb://localhost/test_mongo');  // For building the Connection to the MongoDB database
  mongoose.connection
  .once('open',()=>{
  console.log('Yeah ! It Works');
  done();
}).on('error',(error)=>{
  console.warn('Connection error',error)
});
});

beforeEach((done)=>{                         // To empty the Collection(table) before every test to be run.
mongoose.connection.collections.datas.drop(()=>{
      done();
  })
});
