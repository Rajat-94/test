

const assert = require('assert');
const Data = require('../models/data');

describe('Finding Records',  ()=> {

  var data;
  beforeEach((done)=>{

  data = new Data({   // Creating the user , since Collection within the database gets empty before the test runs.
           name : 'Rajat'
         });
         data.save().then(()=>{
           assert(data.isNew === false);
           done();
         });
  });

    it('Finds a record from MongoDB', (done)=> {
        Data.findOne({name: 'Rajat'}).then(function (result) {
            assert(result.name === 'Rajat');
            done();
        });
    });

});
