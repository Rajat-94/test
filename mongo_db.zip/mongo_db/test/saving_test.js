
const assert = require('assert');
const Data = require('../models/data');
describe('Saving Records', ()=>{

it('Saves a record to the Database', (done)=>{
 var dt = new Data({
   name : 'Rajat'
 });

dt.save().then(()=>{               // Inserting the document(record) within 'data' collection (table)
  assert(dt.isNew === false);
  done();
});

});

});
